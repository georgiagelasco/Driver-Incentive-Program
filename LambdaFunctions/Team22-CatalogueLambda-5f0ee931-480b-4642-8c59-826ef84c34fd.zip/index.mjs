import mysql from 'mysql2/promise';

//Note that the handler assumes the root path is associated with 
//https://n0dkxjq6pf.execute-api.us-east-1.amazonaws.com/dev1/catalogue
const API_STAGE = '/dev1';


export const handler = async (event) => {
    // Extract method and path from requestContext

    const httpMethod = event.requestContext.http.method;
    const path = event.requestContext.http.path;

    //Uncomment me for logging
    console.log('Received event:', JSON.stringify(event, null, 2));

    const schema = 'Team22DB';

    // Log the method and path for debugging
    console.log(`Received request with method: ${httpMethod}, path: ${path}`);

    const connection = await mysql.createConnection({
        host: 'cpsc4911.cobd8enwsupz.us-east-1.rds.amazonaws.com',
        user: 'admin',
        password: '4911Admin2025',
        database: 'Team22DB'
    });


    const corsHeaders = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'OPTIONS, GET, POST, DELETE',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization'
    };

    if (httpMethod === 'OPTIONS') {
        return { statusCode: 200, headers: corsHeaders, body: JSON.stringify({ message: 'CORS preflight successful' }) };
    }

    let response;

    try {

        if (httpMethod === 'GET') {

            console.log(`Entered GET branch`);

            if (path.startsWith(`${API_STAGE}/catalogue`)) {

                // Get the "company_name" parameter from the path
                //const company_name = event.pathParameters?.company_name;
                const company_name = event.queryStringParameters?.company_name;
                // Set up query parameters – pagination for songs inside a catalogue
                const queryParams = event.queryStringParameters || {};

                if (!company_name) {
                    return {
                        statusCode: 400,
                        headers: corsHeaders,
                        body: JSON.stringify({ error: "Missing company_name query parameter" })
                    };
                }

                if (company_name) {
                    // Ensure limit and page are valid positive integers
                    const limit = Math.max(parseInt(queryParams.limit) || 10, 1);
                    const page = Math.max(parseInt(queryParams.page) || 1, 1);
                    const offset = (page - 1) * limit;

                    console.log(`QueryParams: limit=${limit}, page=${page}, offset=${offset}`);

                    try {
                        // Get the catalogue associated with the given company_name.
                        const [catalogueResults] = await connection.execute(
                            `SELECT catalogue_id, company_name
                                FROM Catalogues
                                WHERE company_name = ?;`,
                            [company_name]
                        );

                        if (catalogueResults.length === 0) {
                            response = {
                                statusCode: 404,
                                body: JSON.stringify({ error: `Catalogue not found for company_name: ${company_name}` }),
                                headers: {
                                    'Content-Type': 'application/json',
                                    'Access-Control-Allow-Origin': '*'
                                }

                            };
                        } else {
                            // Assuming a single catalogue per company_name:
                            const catalogue = catalogueResults[0];

                            // Now get the songs for this catalogue with pagination.
                            const songsQuery = `
                                    SELECT s.song_id, s.title, s.artist, s.album, s.artwork_url, s.preview_url, s.store_url, s.release_date, s.genre, cs.price
                                    FROM CatalogueSongs cs
                                    JOIN Songs s ON cs.song_id = s.song_id
                                    WHERE cs.catalogue_id = ?
                                    ORDER BY s.title ASC
                                    LIMIT ${limit} OFFSET ${offset};
                                `;
                            const [songsResults] = await connection.execute(songsQuery, [catalogue.catalogue_id]);

                            // Attach the songs to the catalogue result.
                            catalogue.songs = songsResults;

                            response = {
                                statusCode: 200,
                                body: JSON.stringify({ catalogue, page, limit }),
                                headers: {
                                    'Content-Type': 'application/json',
                                    'Access-Control-Allow-Origin': '*'
                                }
                            };
                        }
                    } catch (error) {
                        console.error("Error fetching catalogue details:", error);
                        response = {
                            statusCode: 500,
                            body: JSON.stringify({ error: "Internal server error" }),
                            headers: {
                                'Content-Type': 'application/json',
                                'Access-Control-Allow-Origin': '*'
                            }
                        };
                    }
                } else {
                    response = {
                        statusCode: 400,
                        body: JSON.stringify({ error: "Missing company_name parameter in path" }),
                        headers: {
                            'Content-Type': 'application/json',
                            'Access-Control-Allow-Origin': '*'
                        }
                    };
                }
            }

            //Add another GET here
            //GET USER PURCHASES
            else if (path.startsWith(`${API_STAGE}/user`)) {
                // Create a regex to match the endpoint pattern expected: /user/{username}/purchases
                const userPurchasesRegex = new RegExp(`^${API_STAGE}/user/([^/]+)/purchases$`);
                const match = path.match(userPurchasesRegex);

                // Guard clause: if the endpoint doesn't match the pattern, return early
                if (!match) {
                    console.error("Invalid endpoint: expected '/user/{username}/purchases'");
                    return {
                        statusCode: 400,
                        headers: {
                            'Content-Type': 'application/json',
                            'Access-Control-Allow-Origin': '*'
                        },
                        body: JSON.stringify({ error: "Invalid API call" })
                    };
                }

                // Extract and decode the email from the URL (username is the email in this case)
                const email = decodeURIComponent(match[1]);
                console.log('Email:', email);

                // Prepare variable to store rows from SQL query
                let rows;
                try {
                    // Execute a parameterized query to join UserPurchases & Songs tables using the email
                    const result = await connection.execute(
                        `SELECT 
                            s.song_id, 
                            s.title, 
                            s.artist, 
                            s.album, 
                            s.artwork_url, 
                            s.preview_url, 
                            s.store_url, 
                            s.release_date, 
                            s.genre, 
                            s.last_cached
                         FROM UserPurchases up
                         INNER JOIN Songs s ON up.song_id = s.song_id
                         WHERE up.email = ?`,
                        [email]
                    );
                    // result[0] contains the rows; assign it for later use in the response.
                    rows = result[0];
                } catch (innerErr) {
                    console.error("Error executing SQL query:", innerErr);
                    return {
                        statusCode: 500,
                        headers: {
                            'Content-Type': 'application/json',
                            'Access-Control-Allow-Origin': '*'
                        },
                        body: JSON.stringify({ error: "Processing Error" })
                    };
                }

                // Build a successful response with the song metadata
                response = {
                    statusCode: 200,
                    headers: {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*'
                    },
                    body: JSON.stringify({ songs: rows })
                };
            }

        }

        else if (httpMethod === 'POST') {

            // POST /catalogue/update
            // Usage: Add a song to a catalogue
            if (path === `${API_STAGE}/catalogue/update`) {

                const requestBody = JSON.parse(event.body);

                const {
                    song_id,
                    title,
                    artist,
                    album,
                    artwork_url,
                    preview_url,
                    store_url,
                    release_date,
                    genre,
                    company_name,
                    price
                } = requestBody;

                if (!song_id ||
                    !title ||
                    !artist ||
                    !album ||
                    !artwork_url ||
                    !preview_url ||
                    !store_url ||
                    !release_date ||
                    !genre ||
                    !company_name ||
                    !price) {

                    response = {
                        statusCode: 400,
                        body: JSON.stringify({ error: "Missing required field(s)" }),
                        headers: {
                            'Content-Type': 'application/json',
                            'Access-Control-Allow-Origin': '*'
                        }
                    };

                    return response;
                };



                //Set schema to our own DB schema
                await connection.query(`USE ${schema}`);

                /* Add code here */

                try {

                    let catalogue_id;

                    //Check if Catalogue exists
                    const [catalogueResult1] = await connection.execute(
                        `
                            SELECT catalogue_id FROM Catalogues WHERE company_name = ?;
                            `,
                        [company_name]
                    );

                    //If not, add to catalogue table
                    if (catalogueResult1.length > 0) {
                        catalogue_id = catalogueResult1[0].catalogue_id;
                    }

                    else {
                        const [catalogueResult2] = await connection.execute(
                            `
                            INSERT INTO Catalogues (company_name) 
                            VALUES (?);
                            `,
                            [company_name]
                        );

                        catalogue_id = catalogueResult2.insertId;
                    }

                    //Check if song exists
                    const [songResult1] = await connection.execute(
                        `
                            SELECT song_id FROM Songs WHERE song_id = ?;
                            `,
                        [song_id]
                    );

                    //If not, add to songs table
                    if (songResult1.length === 0) {
                        const [SongResult2] = await connection.execute(
                            `
                            INSERT INTO Songs (song_id, title, artist, album, artwork_url, preview_url, store_url, release_date, genre) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);
                            `,
                            [song_id, title, artist, album, artwork_url, preview_url, store_url, release_date, genre]
                        );
                    }

                    //Then add to junction table

                    const [junctionResult] = await connection.execute(
                        `INSERT INTO CatalogueSongs (catalogue_id, song_id, price)
                            VALUES (?, ?, ?);`,
                        [catalogue_id, song_id, price]
                    );

                    response = {
                        statusCode: 200,
                        body: JSON.stringify({ message: "Song successfully added to catalogue", catalogue_id }),
                        headers: {
                            'Content-Type': 'application/json',
                            'Access-Control-Allow-Origin': '*'
                        }
                    };

                }

                catch (innerErr) {
                    if (innerErr.code === 'ER_DUP_ENTRY') {
                        console.error("Duplicate entry error:", innerErr);
                        response = {
                            statusCode: 409, // 409 Conflict
                            body: JSON.stringify({ error: "Duplicate entry: The song is already added to this catalogue." }),
                            headers: {
                                'Content-Type': 'application/json',
                                'Access-Control-Allow-Origin': '*'
                            }
                        };
                    }

                    else {
                        console.error("Error during catalogue update:", err);
                        response = {
                            statusCode: 500,
                            body: JSON.stringify({ error: 'Input fields incorrect or SQL error' }),
                            headers: {
                                'Content-Type': 'application/json',
                                'Access-Control-Allow-Origin': '*'
                            }
                        };
                    }
                }
            }

            // POST /catalogue/purchase
            // Usage: Allow a given email to purchase a song from a given catalogue
            // Inputs: email and song_id
            else if (path === `${API_STAGE}/catalogue/purchase`) {
                console.log("Endpoint /catalogue/purchase triggered");

                // Parse and log the incoming request body
                const requestBody = JSON.parse(event.body);
                console.log("Request body:", requestBody);

                const { email, song_id, catalogue_id } = requestBody;

                // Validate input fields
                if (!email || !song_id || !catalogue_id) {
                    console.error("Missing required fields: email, song_id or catalogue_id");
                    return {
                        statusCode: 400,
                        body: JSON.stringify({ error: "Missing required field(s): email, song_id or catalogue_id" }),
                        headers: {
                            "Content-Type": "application/json",
                            "Access-Control-Allow-Origin": "*"
                        }
                    };
                }

                try {
                    // Use the specified schema and begin the transaction
                    console.log(`Switching to schema: ${schema}`);
                    await connection.query(`USE ${schema}`);

                    console.log("Beginning transaction");
                    await connection.beginTransaction();

                    // Fetch song details (price, song_id, company_name) from CatalogueSongs and Catalogues
                    console.log(`Fetching song details for song_id: ${song_id} and catalogue_id: ${catalogue_id}`);
                    const [priceResult] = await connection.execute(
                        `
                    SELECT 
                        cs.song_id, 
                        cs.price, 
                        c.company_name
                    FROM CatalogueSongs cs
                    INNER JOIN Catalogues c ON cs.catalogue_id = c.catalogue_id
                    WHERE cs.song_id = ? AND cs.catalogue_id = ?;
                    `,
                        [song_id, catalogue_id]
                    );
                    console.log("Song details query result:", priceResult);

                    if (priceResult.length === 0) {
                        console.error("Song not found in the specified catalogue.");
                        throw new Error("Song not found in the specified catalogue.");
                    }

                    // Rename the variable to avoid shadowing the input
                    const fetchedSongId = priceResult[0].song_id;
                    const price = priceResult[0].price;
                    const company_name = priceResult[0].company_name;
                    console.log(`Fetched song details: song_id: ${fetchedSongId}, price: ${price}, company_name: ${company_name}`);

                    // Fetch sponsor company ID using the Catalogues table
                    console.log(`Fetching sponsor company id using catalogue_id: ${catalogue_id}`);
                    const [companyResult] = await connection.execute(
                        `
                    SELECT sc.id AS company_id
                    FROM Catalogues c
                    JOIN sponsor_companies sc ON c.company_name = sc.company_name
                    WHERE c.catalogue_id = ?;
                    `,
                        [catalogue_id]
                    );
                    console.log("Company query result:", companyResult);

                    if (companyResult.length === 0) {
                        console.error("No sponsor company found for the given catalogue.");
                        throw new Error("No sponsor company found for the given catalogue.");
                    }

                    const company_id = companyResult[0].company_id;
                    console.log(`Fetched sponsor company id: ${company_id}`);

                    // Get the current total points in the user's wallet for the given sponsor company
                    console.log(`Fetching total points for email: ${email} from sponsor company id: ${company_id}`);
                    const [pointsRows] = await connection.execute(
                        `
                    SELECT SUM(points) AS totalPoints
                    FROM points
                    WHERE email = ? AND sponsorCompanyID = ?;
                    `,
                        [email, company_id]
                    );
                    const totalPoints = pointsRows[0]?.totalPoints ?? 0;
                    console.log(`Fetched total points (before purchase): ${totalPoints}`);

                    // Validate that the user has enough points to cover the price
                    if (totalPoints < price) {
                        throw new Error("Insufficient points for purchase.");
                    }

                    // Deduct points for the purchase
                    // Note: Instead of directly updating, we're using the same logic as the /user/points endpoint.
                    const deductionPoints = -price;
                    const pointsDescription = `Deduction for purchase of song ${song_id}`;
                    console.log(`Inserting a points deduction record: ${deductionPoints} points, description: ${pointsDescription}`);
                    await connection.execute(
                        `
                    INSERT INTO points (email, points, description, sponsorCompanyID)
                    VALUES (?, ?, ?, ?);
                    `,
                        [email, deductionPoints, pointsDescription, company_id]
                    );

                    // Get the new total points after deduction
                    console.log(`Fetching new total points for email: ${email} from sponsor company id: ${company_id}`);
                    const [newPointsRows] = await connection.execute(
                        `
                    SELECT SUM(points) AS totalPoints
                    FROM points
                    WHERE email = ? AND sponsorCompanyID = ?;
                    `,
                        [email, company_id]
                    );
                    const newPoints = newPointsRows[0]?.totalPoints ?? 0;
                    console.log(`Fetched new total points (after purchase): ${newPoints}`);

                    // Record the purchase in the UserPurchases table
                    // Columns: purchase_id, email, song_id, purchase_date, prev_val, new_val
                    console.log("Inserting purchase record into UserPurchases table");
                    await connection.execute(
                        `
                    INSERT INTO UserPurchases (email, song_id, purchase_date, prev_val, new_val)
                    VALUES (?, ?, NOW(), ?, ?);
                    `,
                        [email, song_id, totalPoints, newPoints]
                    );

                    // Commit the transaction
                    console.log("Committing transaction");
                    await connection.commit();
                    console.log("Transaction committed successfully");

                    // Return the response with both previous and new points values
                    return {
                        statusCode: 200,
                        body: JSON.stringify({
                            success: true,
                            data: {
                                fetchedSongId,
                                price,
                                company_id,
                                prev_points: totalPoints,
                                new_points: newPoints
                            }
                        }),
                        headers: {
                            "Content-Type": "application/json",
                            "Access-Control-Allow-Origin": "*"
                        }
                    };

                } catch (error) {
                    console.error("Transaction failed:", error);
                    await connection.rollback();
                    console.log("Rollback successful");
                    return {
                        statusCode: 500,
                        body: JSON.stringify({ error: error.message }),
                        headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
                    };
                }
            }

            // POST /catalogue/lookup
            else if (path === `${API_STAGE}/catalogue/lookup`) {
                try {
                    const body = JSON.parse(event.body);
                    const ids = body.ids;

                    if (!Array.isArray(ids) || ids.length === 0) {
                        return {
                            statusCode: 400,
                            headers: corsHeaders,
                            body: JSON.stringify({ error: "Missing or invalid 'ids' array" }),
                        };
                    }

                    // Now use iTunes API to look them up (optional, or just return the list)
                    // You can even filter from your own Songs table
                    const [songs] = await connection.query(
                        `SELECT * FROM Songs WHERE song_id IN (${ids.map(() => '?').join(',')})`,
                        ids
                    );

                    return {
                        statusCode: 200,
                        headers: corsHeaders,
                        body: JSON.stringify({ results: songs }),
                    };
                } catch (err) {
                    console.error("Error in /catalogue/lookup:", err);
                    return {
                        statusCode: 500,
                        headers: corsHeaders,
                        body: JSON.stringify({ error: "Internal server error" }),
                    };
                }
            }


        }

        else if (httpMethod === 'DELETE') {

            //DELETE /catalogue/update
            //Usage: Delete a song from a catalogue
            if (path === `${API_STAGE}/catalogue/update`) {
                const requestBody = JSON.parse(event.body);
                const { catalogue_id, song_id } = requestBody;

                if (!catalogue_id || !song_id) {
                    response = {
                        statusCode: 400,
                        body: JSON.stringify({ error: "Missing required field(s): catalogue_id and song_id" }),
                        headers: {
                            'Content-Type': 'application/json',
                            'Access-Control-Allow-Origin': '*'
                        }
                    };
                    return response;
                }

                try {
                    // Begin a transaction so that we can safely delete and query in one atomic operation.
                    await connection.beginTransaction();

                    // Delete the junction table record that associates the song with the catalogue.
                    await connection.execute(
                        `DELETE FROM CatalogueSongs WHERE catalogue_id = ? AND song_id = ?;`,
                        [catalogue_id, song_id]
                    );

                    // Now, count how many associations remain for this song.
                    const [countResult] = await connection.execute(
                        `SELECT COUNT(*) AS remaining FROM CatalogueSongs WHERE song_id = ?;`,
                        [song_id]
                    );

                    const remaining = countResult[0].remaining;

                    // Delete the song from Songs table if no remaining associations exist.
                    if (remaining === 0) {
                        try {
                            await connection.execute(`DELETE FROM Songs WHERE song_id = ?;`, [song_id]);

                            response = {
                                statusCode: 200,
                                body: JSON.stringify({ message: "Song deleted successfully" }),
                                headers: {
                                    'Content-Type': 'application/json',
                                    'Access-Control-Allow-Origin': '*'
                                }
                            };
                        } catch (error) {
                            if (error.code === 'ER_ROW_IS_REFERENCED_2') {
                                response = {
                                    statusCode: 409, // Conflict
                                    body: JSON.stringify({
                                        message: "Song removed from catalogue, remains in the database.",
                                        remaining_purchases: true
                                    }),
                                    headers: {
                                        'Content-Type': 'application/json',
                                        'Access-Control-Allow-Origin': '*'
                                    }
                                };
                            } else {
                                response = {
                                    statusCode: 500,
                                    body: JSON.stringify({ error: "Internal server error" }),
                                    headers: {
                                        'Content-Type': 'application/json',
                                        'Access-Control-Allow-Origin': '*'
                                    }
                                };
                            }
                        }
                    }

                    else {
                        response = {
                            statusCode: 200,
                            body: JSON.stringify({
                                message: "Song removed from catalogue",
                                remaining // the number of associations remaining across catalogues.
                            }),
                            headers: {
                                'Content-Type': 'application/json',
                                'Access-Control-Allow-Origin': '*'
                            }
                        };
                    }

                    await connection.commit();

                }

                catch (innerError) {
                    await connection.rollback();
                    console.error("Error during deletion transaction:", innerError);
                    response = {
                        statusCode: 500,
                        body: JSON.stringify({ error: "Internal server error" }),
                        headers: {
                            'Content-Type': 'application/json',
                            'Access-Control-Allow-Origin': '*'
                        }
                    };
                }
            }
        }
    }


    catch (error) {
        response = {
            statusCode: 400,
            body: JSON.stringify({ error: 'Invalid request' }),
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            }
        };
    }

    finally {
        if (connection) await connection.end();
    }

    return response;

};
