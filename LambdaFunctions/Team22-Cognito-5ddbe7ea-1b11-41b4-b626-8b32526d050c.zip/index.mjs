const AWS = require("aws-sdk");

const cognito = new AWS.CognitoIdentityServiceProvider();

exports.handler = async (event) => {
  console.log("User Post Confirmation Trigger Invoked:", event);

  const userPoolId = event.userPoolId;
  const userName = event.userName;

  // Extract user role from custom attribute
  const userRole = event.request.userAttributes["custom:role"];

  console.log(`User Role: ${userRole}`);

  let groupName = null;
  if (userRole === "Administrator") {
    groupName = "Administrators"; // Group name in Cognito
  } else if (userRole === "Driver") {
    groupName = "Drivers";
  } else if (userRole === "Sponsor") {
    groupName = "Sponsors";
  }

  if (groupName) {
    const params = {
      GroupName: groupName,
      UserPoolId: userPoolId,
      Username: userName,
    };

    try {
      await cognito.adminAddUserToGroup(params).promise();
      console.log(`User ${userName} added to ${groupName}`);
    } catch (error) {
      console.error("Error adding user to group:", error);
    }
  }

  return event;
};
