import {
  CognitoIdentityProviderClient,
  AdminGetUserCommand,
  AdminUpdateUserAttributesCommand,
} from "@aws-sdk/client-cognito-identity-provider";

export const handler = async (event) => {
  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
  };

  const client = new CognitoIdentityProviderClient({ region: "us-east-1" });
  const httpMethod = event.requestContext.http.method;
  const path = event.requestContext.http.path;

  try {

    if (httpMethod === "PATCH" && path.endsWith("/admin/cognito-user")) {
      console.log("Received:", { method: httpMethod, path });
      const body = JSON.parse(event.body || "{}");
      const { email, attributes } = body;

      if (!email || !attributes) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: "Missing email or attributes" }),
        };
      }

      const validKeys = [
        "custom:phoneNumber",
        "custom:zipCode",
        "custom:role",
        "custom:sponsorCompany",
      ];

      const userAttributes = Object.entries(attributes)
        .filter(([key, val]) => validKeys.includes(key) && val !== undefined && val !== null)
        .map(([key, val]) => ({ Name: key, Value: val }));

      if (userAttributes.length === 0) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: "No valid attributes to update" }),
        };
      }

      const command = new AdminUpdateUserAttributesCommand({
        UserPoolId: process.env.USER_POOL_ID,
        Username: email,
        UserAttributes: userAttributes,
      });

      await client.send(command);

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ message: "User attributes updated successfully" }),
      };
    }


    // GET from Cognito
    if (httpMethod === "GET") {
      const email = event.queryStringParameters?.email;
      if (!email) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: "Missing email parameter" }),
        };
      }

      const command = new AdminGetUserCommand({
        Username: email,
        UserPoolId: process.env.USER_POOL_ID,
      });

      const result = await client.send(command);

      const attributes = result.UserAttributes.reduce((acc, attr) => {
        acc[attr.Name] = attr.Value;
        return acc;
      }, {});

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ attributes }),
      };
    }

    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: "Method Not Allowed" }),
    };
  } catch (err) {
    console.error("Error handling request:", err);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: "Internal Server Error" }),
    };
  }
};
