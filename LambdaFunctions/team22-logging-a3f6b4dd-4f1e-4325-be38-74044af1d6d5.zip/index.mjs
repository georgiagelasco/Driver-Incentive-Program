console.log("LAMBDA DEPLOYED: version 4", new Date().toISOString());

import mysql from 'mysql2/promise';
import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import { Parser } from 'json2csv';

const API_STAGE = '/dev1';
const s3 = new S3Client({ region: 'us-east-1' });

export const handler = async (event) => {
  const method = event?.requestContext?.http?.method;
  const path = event?.requestContext?.http?.path;

  console.log("FULL EVENT:", JSON.stringify(event, null, 2));
  console.log("HTTP Method:", method);
  console.log("Path:", path);

  // Check that it's a GET to the correct route
  if (method !== "GET" || !path.includes("/reports/sponsor")) {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: "Only GET requests are allowed" }),
      headers: { 'Access-Control-Allow-Origin': '*' },
    };
  }

  let connection;

  try {
    connection = await mysql.createConnection({
      host: 'cpsc4911.cobd8enwsupz.us-east-1.rds.amazonaws.com',
      user: 'admin',
      password: '4911Admin2025',
      database: 'Team22DB'
    });

    const { reportType, sponsorCompanyID, startDate, endDate, auditLogType } = event.queryStringParameters || {};
    console.log("Parsed Params:", { reportType, sponsorCompanyID, startDate, endDate, auditLogType });

    if (!sponsorCompanyID || !startDate || !endDate) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Missing required parameters" }),
        headers: { 'Access-Control-Allow-Origin': '*' },
      };
    }

    let query = "";
    let fields = [];
    let fileName = "";
    let queryParams = [];

    if (reportType === "driver-tracking") {
      query = `
        SELECT 
          u.email AS driverEmail,
          p.points,
          p.description,
          p.created_at,
          s.company_name AS sponsorCompanyName
        FROM points p
        JOIN users u ON p.email = u.email
        JOIN sponsor_companies s ON p.sponsorCompanyID = s.id
        WHERE p.sponsorCompanyID = ? AND DATE(p.created_at) BETWEEN ? AND ?
        ORDER BY p.created_at DESC
      `;
      fields = ["driverEmail", "points", "description", "created_at", "sponsorCompanyName"];
      fileName = `sponsor-reports/${sponsorCompanyID}_driver_tracking_${Date.now()}.csv`;
      queryParams = [sponsorCompanyID, startDate, endDate];
    }

    else if (reportType === "audit-log") {
      switch (auditLogType) {
        case "driver-applications":
          query = `
            SELECT submitted_at AS date, s.company_name AS sponsor, a.driverEmail AS driver, a.status, a.reason
            FROM application a
            JOIN sponsor_companies s ON a.sponsorCompanyID = s.id
            WHERE a.sponsorCompanyID = ? AND DATE(submitted_at) BETWEEN ? AND ?
            ORDER BY submitted_at DESC
          `;
          fields = ["date", "sponsor", "driver", "status", "reason"];
          fileName = `sponsor-reports/${sponsorCompanyID}_audit_driver_applications_${Date.now()}.csv`;
          queryParams = [sponsorCompanyID, startDate, endDate];
          break;

        case "point-changes":
          query = `
            SELECT p.created_at AS date, s.company_name AS sponsor, p.email AS driver, p.points, p.description AS reason
            FROM points p
            JOIN sponsor_companies s ON p.sponsorCompanyID = s.id
            WHERE p.sponsorCompanyID = ? AND DATE(p.created_at) BETWEEN ? AND ?
            ORDER BY p.created_at DESC
          `;
          fields = ["date", "sponsor", "driver", "points", "reason"];
          fileName = `sponsor-reports/${sponsorCompanyID}_audit_point_changes_${Date.now()}.csv`;
          queryParams = [sponsorCompanyID, startDate, endDate];
          break;

        case "password-changes":
          query = `
            SELECT created_at AS date, email AS user, 'Password Change' AS type
            FROM audit_logs
            WHERE action = 'password_change' AND sponsorCompanyID = ? AND DATE(created_at) BETWEEN ? AND ?
            ORDER BY created_at DESC
          `;
          fields = ["date", "user", "type"];
          fileName = `sponsor-reports/${sponsorCompanyID}_audit_password_changes_${Date.now()}.csv`;
          queryParams = [sponsorCompanyID, startDate, endDate];
          break;

        case "login-attempts":
          if (sponsorCompanyID === "ALL") {
            // Admins can fetch all login attempts
            query = `
              SELECT 
              a.created_at AS date,
              a.email AS user,
              a.description AS type,
              ds.sponsorCompanyID,
              sc.company_name AS sponsor
            FROM audit_logs a
            LEFT JOIN driver_sponsors ds ON a.email = ds.driverEmail
            LEFT JOIN sponsor_companies sc ON ds.sponsorCompanyID = sc.id
            WHERE a.action = 'login_attempt'
            ORDER BY a.created_at DESC            
              `;
            fields = ["date", "user", "type", "sponsor"];
            fileName = `sponsor-reports/all_login_attempts_${Date.now()}.csv`;
            queryParams = [startDate, endDate];
          } else {
            // Sponsors see only login attempts from their drivers
            query = `
                SELECT a.created_at AS date, a.email AS user, a.description AS type, s.company_name AS sponsor
                FROM audit_logs a
                JOIN driver_sponsors ds ON a.email = ds.driverEmail
                JOIN sponsor_companies s ON ds.sponsorCompanyID = s.id
                WHERE a.action = 'login_attempt'
                  AND ds.sponsorCompanyID = ?
                  AND DATE(a.created_at) BETWEEN ? AND ?
                ORDER BY a.created_at DESC
              `;
            fields = ["date", "user", "type", "sponsor"];
            fileName = `sponsor-reports/${sponsorCompanyID}_audit_login_attempts_${Date.now()}.csv`;
            queryParams = [sponsorCompanyID, startDate, endDate];
          }
          break;

        default:
          return {
            statusCode: 400,
            body: JSON.stringify({ error: "Invalid audit log type" }),
            headers: { 'Access-Control-Allow-Origin': '*' },
          };
      }
    }

    else if (["sponsor-sales", "driver-sales", "invoice"].includes(reportType)) {
      const isAll = sponsorCompanyID === "ALL";
    
      // If ALL selected and invoice requested, generate combined invoice
      if (isAll && reportType === "invoice") {
        const [catalogues] = await connection.execute(`
          SELECT catalogue_id, company_name
          FROM Catalogues
        `);
    
        let allCSV = "";
        const parser = new Parser({ fields: ["sponsor", "driver", "song", "points_used", "purchase_date"] });
    
        for (const { catalogue_id, company_name } of catalogues) {
          const [rows] = await connection.execute(`
            SELECT 
              c.company_name AS sponsor,
              up.email AS driver,
              s.title AS song,
              (up.prev_val - up.new_val) AS points_used,
              up.purchase_date
            FROM CatalogueSongs cs
            JOIN Catalogues c ON cs.catalogue_id = c.catalogue_id
            JOIN Songs s ON cs.song_id = s.id
            JOIN UserPurchases up ON up.song_id = cs.song_id
            WHERE cs.catalogue_id = ?
            AND DATE(up.purchase_date) BETWEEN ? AND ?
            ORDER BY c.company_name, up.email, up.purchase_date DESC
          `, [catalogue_id, startDate, endDate]);
    
          if (rows.length) {
            const csv = parser.parse(rows);
            const totalFee = rows.reduce((sum, r) => sum + (r.points_used || 0), 0) * 0.01;
            allCSV += `==== ${company_name} ====\n${csv}\nTOTAL FEE (USD): $${totalFee.toFixed(2)}\n\n`;
          }
        }
    
        const fileName = `admin-reports/ALL_invoice_${Date.now()}.csv`;
    
        await s3.send(new PutObjectCommand({
          Bucket: process.env.S3_BUCKET,
          Key: fileName,
          Body: allCSV,
          ContentType: "text/csv",
        }));
    
        return {
          statusCode: 200,
          body: JSON.stringify({
            message: "Combined invoice report generated",
            fileName,
            downloadUrl: `https://${process.env.S3_BUCKET}.s3.amazonaws.com/${fileName}`,
          }),
          headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
        };
      }
    
      // For individual sponsor reports
      const [sponsorRow] = await connection.execute(
        "SELECT company_name FROM sponsor_companies WHERE id = ?",
        [sponsorCompanyID]
      );
    
      if (!sponsorRow.length) {
        throw new Error("Sponsor company not found");
      }
    
      const sponsorName = sponsorRow[0].company_name;
    
      const [catalogueRow] = await connection.execute(
        "SELECT catalogue_id FROM Catalogues WHERE company_name = ?",
        [sponsorName]
      );
    
      if (!catalogueRow.length) {
        throw new Error("Catalogue not found for sponsor company");
      }
    
      const catalogueID = catalogueRow[0].catalogue_id;
    
      const [rows] = await connection.execute(`
        SELECT 
          c.company_name AS sponsor,
          up.email AS driver,
          s.title AS song,
          (up.prev_val - up.new_val) AS points_used,
          up.purchase_date
        FROM CatalogueSongs cs
        JOIN Catalogues c ON cs.catalogue_id = c.catalogue_id
        JOIN Songs s ON cs.song_id = s.song_id
        JOIN UserPurchases up ON up.song_id = cs.song_id
        WHERE cs.catalogue_id = ?
        AND DATE(up.purchase_date) BETWEEN ? AND ?
        ORDER BY c.company_name, up.email, up.purchase_date DESC
      `, [catalogueID, startDate, endDate]);
    
      if (!rows.length) {
        return {
          statusCode: 200,
          body: JSON.stringify({ message: "No results", downloadUrl: null }),
          headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
        };
      }
    
      const fileType = reportType === "invoice" ? "invoice" : reportType;
      const fileName = `admin-reports/${sponsorCompanyID}_${fileType}_${Date.now()}.csv`;
    
      const parser = new Parser({
        fields: ["sponsor", "driver", "song", "points_used", "purchase_date"]
      });
    
      const csvBody = parser.parse(rows);
      const totalFee = rows.reduce((sum, row) => sum + (row.points_used || 0), 0) * 0.01;
    
      const fullCSV = reportType === "invoice"
        ? `${csvBody}\n\nTOTAL FEE (USD): $${totalFee.toFixed(2)}`
        : csvBody;
    
      await s3.send(new PutObjectCommand({
        Bucket: process.env.S3_BUCKET,
        Key: fileName,
        Body: fullCSV,
        ContentType: "text/csv",
      }));
    
      return {
        statusCode: 200,
        body: JSON.stringify({
          message: `${reportType} report generated`,
          fileName,
          downloadUrl: `https://${process.env.S3_BUCKET}.s3.amazonaws.com/${fileName}`,
        }),
        headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
      };
    }
    
    

    const [rows] = await connection.execute(query, queryParams);
    console.log("📦 Data rows:", rows);
    const parser = new Parser({ fields });
    const csv = parser.parse(rows);

    await s3.send(new PutObjectCommand({
      Bucket: process.env.S3_BUCKET,
      Key: fileName,
      Body: csv,
      ContentType: "text/csv",
    }));

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "Report generated",
        fileName,
        downloadUrl: `https://${process.env.S3_BUCKET}.s3.amazonaws.com/${fileName}`,
      }),
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
    };
  } catch (err) {
    console.error("Error generating report:");
    console.error(err?.stack || err); // <- Shows full error stack
  
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: "Failed to generate report",
        details: err?.message || String(err)
      }),
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
    };
  }
   finally {
    if (connection) await connection.end();
  }
};