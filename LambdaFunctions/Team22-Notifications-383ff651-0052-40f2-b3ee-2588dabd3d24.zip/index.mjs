import mysql from 'mysql2/promise';

const API_STAGE = '/dev1';
export const handler = async (event) => {
  const method = event.requestContext.http.method;
  const path   = event.requestContext.http.path;
  const qp     = event.queryStringParameters || {};
  const body   = event.body ? JSON.parse(event.body) : {};
  const parts  = path.split("/");

  const conn = await mysql.createConnection({
    host: 'cpsc4911.cobd8enwsupz.us-east-1.rds.amazonaws.com',
    user: 'admin',
    password: '4911Admin2025',
    database: 'Team22DB'
  });

  const CORS = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*'
  };

  // allow CORS preflight on ANY /dev1/notifications*
  if (method === "OPTIONS" && path.startsWith(`${API_STAGE}/notifications`)) {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "OPTIONS,GET,POST,PATCH,DELETE",
        "Access-Control-Allow-Headers": "Content-Type",
      },
      body: "",
    };
  }

  // GET /notifications?userEmail=…
  if (method === 'GET' && path === `${API_STAGE}/notifications`) {
    const userEmail = qp.userEmail;
    const [rows] = await conn.execute(
      `SELECT notifID, notifName, notifDesc, created_at, is_read
         FROM notifications
         WHERE userEmail = ?
         ORDER BY created_at DESC`,
      [userEmail]
    );
    return { statusCode: 200, headers: CORS, body: JSON.stringify(rows) };
  }

  // PATCH /notifications/{notifID}/read
  if (method === 'PATCH' 
    && parts[1] === API_STAGE.slice(1)
    && parts[2] === "notifications"
    && parts[4] === "read"
  ) {
    const notifID = parseInt(path.split('/').slice(-2)[0], 10);
    await conn.execute(
      `UPDATE notifications SET is_read = TRUE WHERE notifID = ?`,
      [notifID]
    );
    return { statusCode: 200, headers: CORS, body: '{}' };
  }

  // GET /notifications/settings?userEmail=…
  if (method === 'GET' && path === `${API_STAGE}/notifications/settings`) {
    const userEmail = qp.userEmail;
    const [rows] = await conn.execute(
      `SELECT notifName, enabled
         FROM notification_settings
         WHERE userEmail = ?`,
      [userEmail]
    );

    const allTypes = [
      'accepted',      // cannot disable
      'dropped',       // cannot disable
      'points',        // can disable
      'order_placed',  // can disable
      'order_issue'    // can disable
    ];
    const have = new Set(rows.map(r => r.notifName));
    for (const name of allTypes) {
      if (!have.has(name)) {
        await conn.execute(
          `INSERT INTO notification_settings (userEmail, notifName, enabled)
         VALUES (?, ?, TRUE)`,
          [userEmail, name]
        );
        // mirror back into our response
        rows.push({ notifName: name, enabled: 1 });
      }
    }
    return { statusCode: 200, headers: CORS, body: JSON.stringify(rows) };
  }

  // PATCH /notifications/settings
  if (method === 'PATCH' && path === `${API_STAGE}/notifications/settings`) {
    const { userEmail, notifName, enabled } = body;
    await conn.execute(
      `INSERT INTO notification_settings (userEmail, notifName, enabled)
         VALUES (?, ?, ?)
       ON DUPLICATE KEY UPDATE enabled = ?`,
      [userEmail, notifName, enabled, enabled]
    );
    return { statusCode: 200, headers: CORS, body: '{}' };
  }

  // POST /notifications
  if (method === 'POST' && path === `${API_STAGE}/notifications`) {
    const { userEmail, notifName, notifDesc } = body;

    try {
      // 1) check user’s setting
      const [settings] = await conn.execute(
        `SELECT enabled 
           FROM notification_settings
          WHERE userEmail = ? AND notifName = ?`,
        [userEmail, notifName]
      );

      if (settings[0]?.enabled === 0) {
        // disabled → no-op
        return { statusCode: 204, headers: CORS, body: '' };
      }

      // 2) insert into notifications
      await conn.execute(
        `INSERT INTO notifications (userEmail, notifName, notifDesc)
         VALUES (?, ?, ?)`,
        [userEmail, notifName, notifDesc]
      );

      return { statusCode: 201, headers: CORS, body: '{}' };
    } catch (err) {
      console.error('Notification Lambda error:', err);
      return {
        statusCode: 500,
        headers: CORS,
        body: JSON.stringify({ error: 'Database error' })
      };
    }
  }

  return { statusCode: 404, headers: CORS, body: JSON.stringify({ error: 'Not found' }) };
};
